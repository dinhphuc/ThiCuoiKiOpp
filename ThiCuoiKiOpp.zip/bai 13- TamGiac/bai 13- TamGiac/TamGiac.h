#pragma once
#include <iostream>
#include <string>
#include <conio.h>

using namespace std;
class TamGiac
{
private:
	int  a, b, c;
public:
	int XacDinhTamGiac();
	void KTTamGiac();
	TamGiac(int ,int ,int);
	TamGiac();
	~TamGiac();
};

