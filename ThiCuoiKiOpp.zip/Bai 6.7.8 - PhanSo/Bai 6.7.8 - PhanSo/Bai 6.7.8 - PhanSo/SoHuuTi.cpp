﻿#include "SoHuuTi.h"


int SoHuuTi::UCLN(int a, int b)
{
	int c;
	while ((c = (a%b)) != 0)
	{
		a = b;
		b = c;
	}
	return b;
}
void SoHuuTi::RutGon(SoHuuTi &a)
{
	int temp = UCLN(a.a, a.b);
	a.a = a.a / temp;
	a.b = a.b / temp;
}
SoHuuTi SoHuuTi :: operator+(int A)
{
	SoHuuTi temp;
	temp.a = this->a +A*this->b;
	temp.b = this->b;
	RutGon(temp);
	return temp;
}


SoHuuTi operator*(SoHuuTi a, SoHuuTi b)
{
	SoHuuTi temp;
	temp.a = a.a*b.a;
	temp.b = a.b*b.b;
	temp.RutGon(temp);
	return temp;
}
SoHuuTi operator/(SoHuuTi a, SoHuuTi b)
{
	SoHuuTi temp;
	temp.a = a.a*b.b;
	temp.b = a.b*b.a;
	temp.RutGon(temp);
	return temp;
}
//--Nhập Xuất --//
istream& operator>>(istream &input, SoHuuTi &a)
{
	cout << "\nNhap Vao Tu So: ";
	input >> a.a;
	do{
		cout << "Nhap Vao Mau So: ";
		input >> a.b;
		if (a.b == 0)cout << "Nhap b !=0\n ";
	} while (a.b == 0);
	return input;
}
ostream& operator<<(ostream &output, SoHuuTi b)
{
	if (b.a == b.b)b.a = b.b = 1;
	if (b.b == 1)
	{
		cout << b.a;
		return output;
	}
	cout << b.a << "/" << b.b;
	return output;
}
SoHuuTi::SoHuuTi(int TuSo, int MauSo)
{
	this->a = TuSo; this->b = MauSo;
}
SoHuuTi::SoHuuTi()
{
	this->a = 0; this->b = 1;
}
SoHuuTi::~SoHuuTi()
{
}