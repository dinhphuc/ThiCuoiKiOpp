#include "SoHuuTi.h"

void main()
{
	SoHuuTi A(2, 5),B(11,6);
	cout << A;
	cout << endl;
	system("pause");
}