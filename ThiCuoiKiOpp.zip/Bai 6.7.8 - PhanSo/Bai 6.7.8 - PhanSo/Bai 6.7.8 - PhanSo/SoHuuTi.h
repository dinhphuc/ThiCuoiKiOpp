#pragma once
#include <iostream>
using namespace std;
class SoHuuTi
{
private:
	int a, b;
public:
	friend istream& operator >>(istream &input, SoHuuTi &A);
	friend ostream& operator <<(ostream &output, SoHuuTi B);
	friend SoHuuTi operator*(SoHuuTi, SoHuuTi);
	friend SoHuuTi operator/(SoHuuTi, SoHuuTi);
	SoHuuTi operator+(int A);
	int UCLN(int, int);
	void RutGon(SoHuuTi&);
	SoHuuTi(int, int);
	SoHuuTi();
	~SoHuuTi();
};

