#include "SoHuuTi.h"


SoHuuTi::SoHuuTi()
{
}


SoHuuTi::~SoHuuTi()
{
}
