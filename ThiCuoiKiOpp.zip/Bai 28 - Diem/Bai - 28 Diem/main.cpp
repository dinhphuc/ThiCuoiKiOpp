#include "Diem.h"

void main()
{
	
	Diem *D = new DiemHocPhan();
	D->Nhap();	
	cout << endl;
	D->Xuat();
	cout << endl;
	system("pause");
}