#include"Time.h"
#define  Time_frame  -1;






long main()
{
	long value = Time_frame;
	while (value != 0)
	{
		Time::Processing();
		value--;
	}

	system("pause");
	return value;	
}