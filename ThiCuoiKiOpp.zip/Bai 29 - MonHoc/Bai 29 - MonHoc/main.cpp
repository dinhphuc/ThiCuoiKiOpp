#include "MonHoc.h"

void main()
{ 
	MonChuyenNganh *mcn = new MonChuyenNganh();

	mcn->Nhap();
	mcn->Xuat();
	cout << endl;
	system("pause");
}