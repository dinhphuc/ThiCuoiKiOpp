#include "NhanSu.h"

void main()
{
	NhanSu *B = new GiaoVien();
	B->Nhap();
	B->Xuat();
	system("pause");

}